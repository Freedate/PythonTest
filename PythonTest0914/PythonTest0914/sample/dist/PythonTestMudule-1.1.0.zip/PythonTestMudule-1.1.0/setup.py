from distutils.core import setup

setup(
    name = "PythonTestMudule",
    version = "1.1.0",
    py_modules = ["printMovie"],
    author = "Freeday",
    author_email = "kod9326@gmail.com",
    url = "http://google.com",
    description = "Test Module",
    )